package com.football.football_standings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballStandingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
